﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using ResourceHeader;
using System.Collections;

using System.Xml;

namespace ResourceCreator
{
    public partial class ResCreator : Form, IHotSpotObserver
    {
        SceneCanvas mSceneCanvas = SceneCanvas.Self();
        ControllerCommandHistory mHostory = ControllerCommandHistory.Instance;
        DrawElement DerawingObject;
        public ResCreator()
        {
            InitializeComponent();
            ElementTracker.Instance.CreateHotSpot();
            //
            
            mSceneCanvas.Canvas = this.m_Canvas;
        }

        private void UpdatePropertyList(DrawElement obj)
        {
            // Depends on Object....
            if (obj != null)
            {
                obj.Factory.PopulatePropertyList(obj.Property);
                obj.Factory.UpdateProperty(obj);
                FactoryManager.getInstance().SetSelectedFactory(obj.Factory);
            }
        }

        private void m_Canvas_Paint(object sender, PaintEventArgs e)
        {
            mSceneCanvas.draw(e.Graphics);
            ElementTracker.Instance.draw(e.Graphics);
        }
        //
        private void m_Canvas_MouseUp(object sender, MouseEventArgs e)
        {
            if (DerawingObject != null && DerawingObject.DrawState == DrawState.CreatingObject)
            {
                DerawingObject.onMouseUp(e);

                FactoryShape factoryShape = FactoryManager.getInstance().SelectTool(0);
                Action action = factoryShape.CreateAddAction(DerawingObject, SceneCanvas.Self());
                DerawingObject.DrawState = DrawState.Selected;

                ElementProperty prop = new ElementProperty();
                DrawElement model = DerawingObject;

                String strVal = factoryShape.Name + factoryShape.List.Count.ToString();
                model.Property = prop;
                prop.SetValue("Name", strVal.Trim());
                prop.SetValue("Id", "1");
                prop.SetValue("Location", model.Location.X.ToString() + "," + model.Location.Y.ToString());
                prop.SetValue("Text", model.Text);
                prop.SetValue("Size", model.Width.ToString() + "," + model.Height.ToString());

                action.SetParam(prop);
                mHostory.ExcuteAction(action);
                m_Canvas.Invalidate();
                DerawingObject = null;
                m_Canvas.Cursor = System.Windows.Forms.Cursors.Default;
            }
            else
            {
                mSceneCanvas.onMouseUp(e);
                ElementTracker.Instance.onMouseUp(e);
            }
            m_Canvas.Invalidate();
        }
        //
        private void m_Canvas_MouseMove(object sender, MouseEventArgs e)
        {
            if(DerawingObject != null && DerawingObject.DrawState == DrawState.CreatingObject)
            {
                DerawingObject.onMouseMove(e);
            }
            else
            {
                mSceneCanvas.onMouseMove(e);
                ElementTracker.Instance.onMouseMove(e);
            }

            m_Canvas.Invalidate();
        }
        //
        private void m_Canvas_MouseDown(object sender, MouseEventArgs e)
        {
            if (DerawingObject != null && DerawingObject.DrawState == DrawState.CreatingObject)
            {
                DerawingObject.onMouseDown(e);
            }
            else
            {
                mSceneCanvas.onMouseDown(e);
                if (ElementTracker.Instance.FindHotSpot(e.Location) == null)
                {
                    ElementTracker.Instance.HitObj = SceneCanvas.Self().GetHitItem(e.Location);
                    // Click on Diff Object
                    UpdatePropertyList(ElementTracker.Instance.HitObj);
                }

                ElementTracker.Instance.onMouseDown(e);
            }

            m_Canvas.Invalidate();
            
        }
        //
        private void mRedo_Click(object sender, EventArgs e)
        {
            mHostory.HandleRedo();
            m_Canvas.Invalidate();
        }
        //
        private void mUndo_Click(object sender, EventArgs e)
        {
            mHostory.HandleUndo();
            m_Canvas.Invalidate();
        }
        //
        private void ResCreator_Load(object sender, EventArgs e)
        {
          
            m_grpLeft.Height = this.Height - m_listItems.Top - 56;
            m_listItems.Left = m_grpLeft.Left + 5;
            m_listItems.Width = m_grpLeft.Width - 10;

            
            m_grpRight.Height = m_grpLeft.Height;
            m_grpRight.Width = this.Width - m_grpLeft.Width - 30;
            mHostory.ClearHistory();
            
        }
        //
        private void listBox1_MouseDoubleClick(object sender, MouseEventArgs e)
        {

            int index = m_listItems.SelectedIndex;
            FactoryShape factoryShape = FactoryManager.getInstance().SelectTool(0);
            DrawElement model = factoryShape.CreateControl();

            ElementProperty prop = new ElementProperty();
          
            String strVal = factoryShape.Name + factoryShape.List.Count.ToString();
            model.Property = prop;
            prop.SetValue("Name", strVal.Trim());
            prop.SetValue("Id", index.ToString());
            prop.SetValue("Location", model.Location.X.ToString() + "," + model.Location.Y.ToString());
            prop.SetValue("Text", model.Text);
            prop.SetValue("Size", model.Width.ToString() + "," + model.Height.ToString());
            //
            factoryShape.UpdateProperty(model);
            //

            if(m_listItems.SelectedItem.ToString() == "Fixed Rectangle")
            {
                Action action = factoryShape.CreateAddAction(model, SceneCanvas.Self());
                action.SetParam(prop);
                mHostory.ExcuteAction(action);
                m_Canvas.Invalidate();
            }
            else if(m_listItems.SelectedItem.ToString() == "Draw Rectangle")
            {
                //Action action = factoryShape.CreateAddAction(model, SceneCanvas.Self());
                //action.SetParam(prop);
                //action.execute();
                model.DrawState = DrawState.CreatingObject;
                //ElementTracker.Instance.TrackObj = model;
                //m_Canvas.Invalidate();
                model.ItemSize = new Size(0, 0);
                DerawingObject = model;

                SceneCanvas.Self().Add(model);

                m_Canvas.Cursor = System.Windows.Forms.Cursors.Cross;
            }
        }


        #region IHotSpotObserver Members

        public void OnHotSpot(ElementTracker.HotSpot hotSpot)
        {
            this.m_Canvas.Cursor = ElementTracker.Instance.GetHotSpotCursor(hotSpot);
        }

        #endregion

       
    }
}
