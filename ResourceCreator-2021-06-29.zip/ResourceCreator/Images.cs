enum IMAGES
{
  Start = -1,
  ButtonNormal_png = 0,
  CheckBoxNormal_png = 1,
  ControlBox_png = 2,
  RadioButtonNormal_png = 3,
  End
}
