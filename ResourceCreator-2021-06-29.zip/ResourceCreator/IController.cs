﻿
using System;

namespace ResourceCreator
{
    public interface IController
    {
        void dispatchRequest(Object obj);
    }
}
