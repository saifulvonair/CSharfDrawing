﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using ResourceHeader;
using System.Collections;

using System.Xml;

namespace ResourceCreator
{
    public partial class ResCreator : Form
    {
        DrawingCanvas mSceneCanvas = DrawingCanvas.Self();
        ControllerCommandHistory mHostory = ControllerCommandHistory.Instance;
        //DrawElement DerawingObject;
        public ResCreator()
        {
            InitializeComponent();
            mSceneCanvas.initialize(new Size(), this.m_Canvas);
        }

        private void mRedo_Click(object sender, EventArgs e)
        {
            mHostory.HandleRedo();
            m_Canvas.Invalidate();
        }
        //
        private void mUndo_Click(object sender, EventArgs e)
        {
            mHostory.HandleUndo();
            m_Canvas.Invalidate();
        }
        //
        private void ResCreator_Load(object sender, EventArgs e)
        {
          
            m_grpLeft.Height = this.Height - m_listItems.Top - 56;
            m_listItems.Left = m_grpLeft.Left + 5;
            m_listItems.Width = m_grpLeft.Width - 10;

            
            m_grpRight.Height = m_grpLeft.Height;
            m_grpRight.Width = this.Width - m_grpLeft.Width - 30;
            mHostory.ClearHistory();
            
        }
        //
        private void listBox1_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            if (m_listItems.SelectedItem == null)
                return;

            int index = m_listItems.SelectedIndex;
            FactoryShape factoryShape = FactoryManager.getInstance().SelectTool(0);
            DrawElement model = factoryShape.CreateControl();

            ElementProperty prop = new ElementProperty();
          
            String strVal = factoryShape.Name + factoryShape.List.Count.ToString();
            model.Property = prop;
            prop.SetValue("Name", strVal.Trim());
            prop.SetValue("Id", index.ToString());
            prop.SetValue("Location", model.Location.X.ToString() + "," + model.Location.Y.ToString());
            prop.SetValue("Text", model.Text);
            prop.SetValue("Size", model.Width.ToString() + "," + model.Height.ToString());
            //
            factoryShape.UpdateProperty(model);
            //
            

            if(m_listItems.SelectedItem.ToString() == "Fixed Rectangle")
            {
                Action action = factoryShape.CreateAddAction(model, DrawingCanvas.Self());
                action.SetParam(prop);
                mHostory.ExcuteAction(action);
                m_Canvas.Invalidate();
            }
            else if(m_listItems.SelectedItem.ToString() == "Draw Rectangle")
            {
                //Action action = factoryShape.CreateAddAction(model, SceneCanvas.Self());
                //action.SetParam(prop);
                //action.execute();
                model.DrawState = DrawState.CreatingObject;
                //ElementTracker.Instance.TrackObj = model;
                //m_Canvas.Invalidate();
                model.ItemSize = new Size(0, 0);
                //DerawingObject = model;
                mSceneCanvas.DrawingObject = model;

                DrawingCanvas.Self().Add(model);

                m_Canvas.Cursor = System.Windows.Forms.Cursors.Cross;
            }
        }       
    }
}
