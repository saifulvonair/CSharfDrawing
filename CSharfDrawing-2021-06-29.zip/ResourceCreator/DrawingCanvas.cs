using System;
using System.Drawing;
using System.Collections;
using System.Windows.Forms;
using ResourceHeader;

namespace ResourceCreator
{
    public class DrawingCanvas : IDrawElementList, IHotSpotObserver
    {
        //Graphics mGraphics;
        ArrayList mList;
        static DrawingCanvas mInstance = null;
        Size mSzCanvasSize;
        //Image mPicture;
        IntPtr mHandle;
        IDrawable mDrawable;
        PictureBox mCanvas;
        Rectangle mRectDirty;
        //ElementTracker mTracking;

        public IntPtr Handle { get { return mHandle; } }
        public PictureBox Canvas { get { return mCanvas; } set { mCanvas = value; } }

        // public ElementTracker Tracker { get { return mTracking; } }
        public DrawElement DrawingObject;

        public Size Size 
        {
            get {return mSzCanvasSize; }
            set { mSzCanvasSize = value; }
        }

        DrawingCanvas()
        {
            //mGraphics = null;
            mDrawable = null;
            mList = new ArrayList();
            mRectDirty = new Rectangle(0,0,0,0);
        }

        public static DrawingCanvas Self()
        {
            if (null == mInstance) {
                mInstance = new DrawingCanvas();
            }
            return mInstance;        
        }

        public IDrawable Drawable
        {
            get { return mDrawable; }
            set { mDrawable = value; }
        }

        public void initialize(Size aSize, PictureBox pictureBox)
        {
            /*mPicture = new Bitmap(aSize.Width, aSize.Height);
            mGraphics = Graphics.FromImage(mPicture);
            */

            ElementTracker.Instance.CreateHotSpot();
            mSzCanvasSize = aSize;
            this.Canvas = pictureBox;

            pictureBox.Paint += new System.Windows.Forms.PaintEventHandler(this.onPaint);
            pictureBox.MouseDown += new System.Windows.Forms.MouseEventHandler(this.onMouseDown);
            pictureBox.MouseMove += new System.Windows.Forms.MouseEventHandler(this.onMouseMove);
            pictureBox.MouseUp += new System.Windows.Forms.MouseEventHandler(this.onMouseUp);
            //

            ElementTracker.Instance.AttachHotSpotObserver(this);

        }

        public void updateArea(Rectangle aRect)
        {
            mRectDirty.X = mRectDirty.X|aRect.X;
            mRectDirty.Y = mRectDirty.Y | aRect.Y;
            mRectDirty.Width = mRectDirty.Width | aRect.Width;
            mRectDirty.Height = mRectDirty.Height | aRect.Height;
            ////
            //if (null != mCanvas)
            //{
            //    mCanvas.Invalidate(aRect);
            //}
        }

        
        public void Add(DrawElement aDrawable)
        {
            if (null != mList && null != aDrawable) {
                if (!mList.Contains(aDrawable)) {                                        
                    mList.Add(aDrawable);
                }
            }
        }

        public void Remove(DrawElement obj)
        {
            mList.Remove(obj);
        }
      
        public void removeAll()
        {
            mList.Clear();        
        }

      
        public void drawBackground(Graphics aGraphics)
        {
            Brush brushBack = new SolidBrush(Color.White);
            Pen penRect = new Pen(Color.Black);
            
            aGraphics.FillRectangle(brushBack,
                                    0,
                                    0,
                                    mSzCanvasSize.Width,
                                    mSzCanvasSize.Height);


            //aGraphics.DrawRectangle(penRect,
            //                        0,
            //                        0,
            //                        this.mSzCanvasSize.Width-1,
            //                        this.mSzCanvasSize.Height-1);

            brushBack.Dispose();
        }

        public void draw(Graphics aGraphics)
        {
            //drawBackground(aGraphics);            
            foreach (DrawElement aDrawable in mList)
            {
                if (aDrawable.Show)
                {
                    aDrawable.draw(aGraphics);
                }
            }

            //mTracking.draw(aGraphics);
        }

        private void UpdatePropertyList(DrawElement obj)
        {
            // Depends on Object....
            if (obj != null)
            {
                obj.Factory.PopulatePropertyList(obj.Property);
                obj.Factory.UpdateProperty(obj);
                FactoryManager.getInstance().SetSelectedFactory(obj.Factory);
            }
        }

        private void onPaint(object sender, PaintEventArgs e)
        {
            this.draw(e.Graphics);
            ElementTracker.Instance.draw(e.Graphics);
        }

        public void onMouseDown(object sender, MouseEventArgs e)
        {
            if (DrawingObject != null && DrawingObject.DrawState == DrawState.CreatingObject)
            {
                DrawingObject.onMouseDown(e);
            }
            else
            {
                if (ElementTracker.Instance.FindHotSpot(e.Location) == null)
                {
                    ElementTracker.Instance.HitObj = DrawingCanvas.Self().GetHitItem(e.Location);
                    // Click on Diff Object
                    UpdatePropertyList(ElementTracker.Instance.HitObj);
                }

                ElementTracker.Instance.onMouseDown(e);
            }

            mCanvas.Invalidate();
        }

        public void onMouseUp(object sender, MouseEventArgs e)
        {
            if (DrawingObject != null && DrawingObject.DrawState == DrawState.CreatingObject)
            {
                DrawingObject.onMouseUp(e);

                FactoryShape factoryShape = FactoryManager.getInstance().SelectTool(0);
                Action action = factoryShape.CreateAddAction(DrawingObject, DrawingCanvas.Self());
                DrawingObject.DrawState = DrawState.Selected;

                ElementProperty prop = new ElementProperty();
                DrawElement model = DrawingObject;

                String strVal = factoryShape.Name + factoryShape.List.Count.ToString();
                model.Property = prop;
                prop.SetValue("Name", strVal.Trim());
                prop.SetValue("Id", "1");
                prop.SetValue("Location", model.Location.X.ToString() + "," + model.Location.Y.ToString());
                prop.SetValue("Text", model.Text);
                prop.SetValue("Size", model.Width.ToString() + "," + model.Height.ToString());

                action.SetParam(prop);
                ControllerCommandHistory.Instance.ExcuteAction(action);
                mCanvas.Invalidate();
                DrawingObject = null;
                mCanvas.Cursor = System.Windows.Forms.Cursors.Default;
            }
            else
            {
                ElementTracker.Instance.onMouseUp(e);
            }
            mCanvas.Invalidate();
        }

        public void onMouseMove(object sender, MouseEventArgs e)
        {
            if (DrawingObject != null && DrawingObject.DrawState == DrawState.CreatingObject)
            {
                DrawingObject.onMouseMove(e);
            }
            else
            {
                ElementTracker.Instance.onMouseMove(e);
            }

            mCanvas.Invalidate();
        }
      
        public DrawElement GetHitItem(Point point)
        {
            DrawElement hitItem = null;
            int count = mList.Count - 1;

            for (int i = count; i >= 0; i--)
            {
                hitItem = (DrawElement)mList[i];
                if (hitItem.hitTest(point))
                {
                    return hitItem;
                }
            }

            return null;
        }

        public void OnHotSpot(ElementTracker.HotSpot hotSpot)
        {
            this.mCanvas.Cursor = ElementTracker.Instance.GetHotSpotCursor(hotSpot);
        }
    }
}
