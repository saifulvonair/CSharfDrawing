﻿using System;
using System.Collections.Generic;

namespace ResourceCreator
{
    //
    public enum ITEM_TYPE
    {
        Rectangle = 0,            
    };

    public class PropertyObject
    {
        private String m_Text;
        private String m_Name;
        private String[] m_list;
        private String m_TextNew;
        private ITEM_TYPE m_eType;
        //
        private String m_sDefaultText;
        //
        public String Text { get { return m_Text; } set { m_Text = value; } }
        public String DefaultText { get { return m_sDefaultText; } set { m_sDefaultText = value; } }
        public String Name { get { return m_Name; } set { m_Name = value; } }
        public ITEM_TYPE Type { get { return m_eType; } set { m_eType = value; } }
        public String[] List { get { return m_list; } set { m_list = value; } }
        public String TextNew { get { return m_TextNew; } set { m_TextNew = value; } }
        public PropertyObject(String name, String val, ITEM_TYPE type)
        {
            m_Text = val;
            m_Name = name;
            m_eType = type;
            m_list = null;
            m_sDefaultText = val;
        }
        //
        public bool IsModified()
        {
            return (m_sDefaultText != m_Text);
        }
    }
    //
    public class ElementProperty
    {
       // protected Dictionary<String, String[]> m_dicPropertyData;
        protected bool m_bModified;
        protected Dictionary<String, PropertyObject> m_dicListProperty;

        public virtual bool IsModified() { return false; }
        public Dictionary<String, PropertyObject> List { get { return m_dicListProperty; } }

        //
        public virtual void InitPropertyMap()
        {
            String[] sList = { "true", "false" };
            //m_dicPropertyData.Add("Enable", sList);
            //m_dicPropertyData.Add("Visible", sList);
            AddObjValue("Enable", sList);
            AddObjValue("Visible", sList);
        }
        //
        protected void AddObjValue(String name, String[] values)
        {
            PropertyObject obj = GetPropObj(name);
            obj.List = values;
        }
        //
        public ElementProperty()
        {
           
           m_bModified = false;
           m_dicListProperty = new Dictionary<string, PropertyObject>();

           m_dicListProperty.Add("Id", new PropertyObject("Id", "1", ITEM_TYPE.Rectangle));
           m_dicListProperty.Add("Name", new PropertyObject("Name", "Button", ITEM_TYPE.Rectangle));
           m_dicListProperty.Add("Text", new PropertyObject("Text", "Button", ITEM_TYPE.Rectangle));
           m_dicListProperty.Add("Enable",new PropertyObject("Enable", "true", ITEM_TYPE.Rectangle));
           m_dicListProperty.Add("Location", new PropertyObject("Location", "0,0", ITEM_TYPE.Rectangle));
           m_dicListProperty.Add("Size", new PropertyObject("Size", "76,27", ITEM_TYPE.Rectangle));
           m_dicListProperty.Add("Visible", new PropertyObject("Visible", "true", ITEM_TYPE.Rectangle));
        }
        //
        public String GetValue(String name)
        {
            try
            {
                return m_dicListProperty[name].Text;
            }
            catch (Exception e) { }

            return "";
        }
        //
        public PropertyObject GetPropObj(String name)
        {
            try
            {
                return m_dicListProperty[name];
            }
            catch (Exception e) { }

            return null;
        }
        //
        public void SetValue(String name, String text)
        {
            PropertyObject obj = GetPropObj(name);

            if (obj != null)
            {
                obj.Text = text;
            }
        }
        //
        static public void CopyProperty(ElementProperty propOld, ElementProperty propNew)
        {
            PropertyObject propObjOld = null;
            PropertyObject propObjNew = null;
            int size = propOld.List.Count;

            List<PropertyObject> listOld = new List<PropertyObject>(propOld.List.Values);
            List<PropertyObject> listNew = new List<PropertyObject>(propNew.List.Values);


            for (int i = 0; i < size; i++)
            {
                propObjNew = listNew[i];
                propObjOld = listOld[i];
                propObjOld.Text = propObjNew.Text;
            }
        }
        //
        public bool IsPropertyModified(String name)
        {
            PropertyObject propObj = GetPropObj(name);

            if (propObj != null)
            {
                return propObj.IsModified();
            }

            return false;
        }
    }
}   
